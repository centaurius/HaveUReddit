from selenium import webdriver
from selenium.webdriver.common.keys import keys
import wordcloud as wc
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


path_to_chromedriver = 'C:\Users\ovoImran\Downloads\chromedriver'
driver = webdriver.Chrome(executable_path= path_to_chromedriver)

driver.get("http://www.wolframalpha.com/")

