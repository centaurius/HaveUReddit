"""

uses matplotlib to plot graphs
"""
import matplotlib.pyplot as plt
import wordcloud
import operator

dictionary = wordcloud.alg()


#k = len(dictionary.items()[0])
#
print(dictionary)
dictionary = dict(dictionary)
print(dictionary)
sorted_x = sorted(dictionary.items(), key=operator.itemgetter(1))
print(sorted_x)
sorted_x = dict(sorted_x)
first_elts = [x[0] for x in sorted_x]
second = [x[1] for x in sorted_x]
k = len(first_elts)
print(first_elts)
print(second)
#length_dict = {key: len(value) for key, value in sorted_x.items()}

#length_key = length_dict['key']  # length of the list stored at `'key'` ...

plt.plot(range(k), second, align = 'center')

plt.xticks(range(k), first_elts)

plt.show()