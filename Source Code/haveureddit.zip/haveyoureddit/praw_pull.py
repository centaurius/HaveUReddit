import praw

def main():
    r = praw.Reddit('Comment Scraper ')

    subreddit = r.get_subreddit('hiphopheads')
    set_limit = 1
    posts = subreddit.get_top_from_day(limit = set_limit)
    id_list = []
    for submission in posts:
        id_list.append(str(submission.id))
    print id_list
    output_list = []


    file = open("comments.txt", "w")
    for i in range(set_limit):
        submission = r.get_submission(submission_id= id_list[i] )
        submission.replace_more_comments(limit=None, threshold=0)
        flat_comments = praw.helpers.flatten_tree(submission.comments)

        for comment in flat_comments:
            if "[deleted]" != comment.body and "http" not in comment.body:
                #output_list.append((str(comment.body)))
                file.write((str(comment.body)))
            else:
                pass

    return file

print (file)
file.close
main()
#file.close()
#eal_list = []
#for temp in output_list:
#    real_list.append(temp.split(" "))
#    output_list[i] = output_list[i]
#print real_list