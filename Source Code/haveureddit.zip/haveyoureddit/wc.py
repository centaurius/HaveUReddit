"""
parses text and gets top words

opens up a webbrowser
imputs a list to wolfram alpha

"""

import operator
import praw
import webbrowser
#file = open("test2.txt")

file = open("test.txt")
file = open("comments.txt")
x = "streetwear"
"""
def praw_pull_main(x):
    r = praw.Reddit('Comment Scraper ')

    subreddit = r.get_subreddit('x')
    set_limit = 5

    posts = subreddit.get_top_from_hour(limit = set_limit)
    id_list = []
    for submission in posts:
        id_list.append(str(submission.id))
    #print id_list
    output_list = []

    #file = open("comments.txt", "w")
    #file = open("comments.txt", "w")
    for i in range(set_limit):
        submission = r.get_submission(submission_id= id_list[i] )
        submission.replace_more_comments(limit=None, threshold=0)
        flat_comments = praw.helpers.flatten_tree(submission.comments)

        for comment in flat_comments:
            if "[deleted]" != comment.body and "http" not in comment.body:
                #output_list.append((str(comment.body)))
                file.write((str(comments.body)))
            else:
                pass

#print output_list


#eal_list = []
#for temp in output_list:
#    real_list.append(temp.split(" "))
#    output_list[i] = output_list[i]
#print real_list
"""
def alg():
    file = open("test4.txt")
    dict = {}
    for line in file:
        counter = 0
        line = line.strip().split(" ")
        #dict={}
        #print(line)
        for word in line:
            word = word.strip(" ")
            #print(word)
            words = word.lower()
            #print(words)
            #
            #for each in words:
            #counter = 0
            comparator = words


            #if comparator in words:
        """
        for word in words:
            if word not in ["have", "I", "it", "for", "not", "on", "with", "he", "of", "the" ]:
                counter += 1
                print(counter)
                print(comparator)
                dict[comparator]= counter
            else:
                pass

        print(dict)
        """
        #og working version
        for word in words:
            counter += 1
            #print(counter)
            #print(comparator)
            dict[comparator]= counter
        #print(dict)

        sorted_dict = sorted(dict.items(), key=operator.itemgetter(1))
        #print(sorted_dict)
        sorted_dict.reverse()
        #print(sorted_dict)
            #return dict
    return sorted_dict

def alg_list(list):
    dict = {}
    for i in range(len(list)):
        counter = 0
        lower_i = i.lower()
        #print(lower_i)
        comparator = lower_i
        for i in lower_i:
            counter += 1
            #print(counter)
            #print(comparator)
            dict[comparator] = counter
        #print(dict)
        sorted_dict = sorted(dict.items(), key=operator.itemgetter(1))
        #print(sorted_dict)
        sorted_dict.reverse()
        print(sorted_dict)

    return dict


print(alg())
#print(dict)
#file.close()
#list = praw_pull_main()
#alg_list(list)



    #text_File= line.lower()
    #print(text_File)

