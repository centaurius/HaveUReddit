import turtle
from random import randint
from random import random
import colorsys

import wc
dict = wc.alg()
print(dict)
turtle.setup(600, 800)
turtle.colormode(255)
turtle.penup()
turtle.goto(-150, -200)
turtle.pendown()


def percentage(part, whole):
  return 100 * float(part)/float(whole)



def main():
    xsize = 38
    for j,k in dict:
        x = randint(0, 200)
        y = randint(0, 300)
        rotations = randint(0, 360)
        turtle.left(rotations)
        rotations = randint(0, 360)
        turtle.right(rotations)
        red = randint(0,255)
        green = randint(0,255)

        blue = randint(0,255)

        turtle.pencolor(red, green, blue)
        turtle.penup()
        #turtle.setx(x)
        #turtle.sety(y)
        size = percentage(xsize, 600)
        turtle.pencolor(red, green, blue)
        turtle.down()


        turtle.write(str(j), font=("arial", xsize, "normal"))

        turtle.penup()
        turtle.settiltangle(0)
        turtle.seth(0)
        turtle.left(90)
        xsize = xsize -4
        turtle.forward(xsize)

    input("HIT ENTER TO FINISH")

#def main():
    #turtle.write("hello World!!")
    #input("Hit enter to finsih")


main()

