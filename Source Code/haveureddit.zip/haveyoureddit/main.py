"""
main function for top word cloud
"""
import praw

r = praw.Reddit("Top words based on comments")
comments = 


